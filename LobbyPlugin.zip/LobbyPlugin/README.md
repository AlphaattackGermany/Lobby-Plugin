# LobbyPlugin

Ein professionelles Minecraft Lobby-Plugin für Version 1.21-1.21.4

## Features

### Double Jump
- Spieler können zweimal springen (Double Jump)
- Raketen-Sound beim Springen
- 3 Sekunden Cooldown zwischen den Sprüngen
- Automatische Aktivierung beim Landen auf dem Boden
- Verhindert unerwünschtes Weiterfliegen während Cooldown

### Player Visibility Toggle
- **Rotes Dye**: Versteckt alle Spieler visuell (nur für dich)
- **Grünes Dye**: Zeigt alle Spieler wieder an
- Spieler sind vollständig unsichtbar (keine Nametags, keine Sounds)
- Jeder Spieler kann individuell einstellen, ob er andere sieht
- Behebt Bug beim Ducken und Item-Nutzung

### Performance
- Event-basierte Item-Vergabe statt Timer
- Optimierte Cooldown-Verwaltung
- Minimale Server-Last

## Installation

### Voraussetzungen
- Java 21
- Maven 3.6+
- Minecraft Server 1.21-1.21.4

### Build
```bash
mvn clean package
```

Die fertige JAR-Datei befindet sich in `target/LobbyPlugin-1.0.0.jar`

### Server Installation
1. Die JAR-Datei in den `plugins` Ordner des Servers kopieren
2. Server neustarten
3. Plugin ist sofort einsatzbereit

## Technische Details

- **Java Version**: 21
- **Minecraft Version**: 1.21-1.21.4 (Hauptversion 1.21.4)
- **Build System**: Maven
- **API**: Spigot API 1.21.4

## Author

Sweatervibes
