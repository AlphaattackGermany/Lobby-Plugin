package de.sweatervibes.lobby;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class DoubleJumpListener implements Listener {

    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> recentJumps = new HashSet<>();
    private final Plugin plugin;

    public DoubleJumpListener(Plugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() &&
            event.getFrom().getBlockY() == event.getTo().getBlockY() &&
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        GameMode mode = player.getGameMode();

        if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) {
            return;
        }

        if (!player.isOnGround() || player.isFlying()) {
            return;
        }

        UUID playerId = player.getUniqueId();

        if (!recentJumps.contains(playerId)) {
            player.setAllowFlight(true);
        } else {
            Long lastJump = cooldowns.get(playerId);
            if (lastJump != null && System.currentTimeMillis() - lastJump >= 3000) {
                recentJumps.remove(playerId);
                cooldowns.remove(playerId);
                player.setAllowFlight(true);
            }
        }
    }

    @EventHandler
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();

        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }

        event.setCancelled(true);

        UUID playerId = player.getUniqueId();
        long currentTime = System.currentTimeMillis();

        if (cooldowns.containsKey(playerId)) {
            long lastJump = cooldowns.get(playerId);
            long timePassed = currentTime - lastJump;

            if (timePassed < 3000) {
                long timeLeft = 3000 - timePassed;
                player.sendMessage("§cCooldown: §7" + (timeLeft / 1000.0) + "s");
                return;
            }
        }

        cooldowns.put(playerId, currentTime);
        recentJumps.add(playerId);

        Vector direction = player.getLocation().getDirection();
        Vector velocity = direction.multiply(0.8).setY(0.8);
        player.setVelocity(velocity);
        player.setAllowFlight(false);
        player.setFlying(false);

        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && player.isOnGround()) {
                recentJumps.remove(playerId);
            }
        }, 40L);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        cooldowns.remove(playerId);
        recentJumps.remove(playerId);
    }
}
