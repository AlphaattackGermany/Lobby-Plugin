package de.sweatervibes.lobby;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class LobbyPlugin extends JavaPlugin implements Listener {

    private static final String RED_DYE_NAME = "§cSpieler verstecken";
    private static final String GREEN_DYE_NAME = "§aSpieler anzeigen";

    private VisibilityManager visibilityManager;
    private DoubleJumpListener doubleJumpListener;
    private ItemStack redDyeItem;
    private ItemStack greenDyeItem;

    @Override
    public void onEnable() {
        createVisibilityItems();
        
        this.visibilityManager = new VisibilityManager(this);
        this.doubleJumpListener = new DoubleJumpListener(this);
        
        Bukkit.getPluginManager().registerEvents(doubleJumpListener, this);
        Bukkit.getPluginManager().registerEvents(new VisibilityListener(this, visibilityManager), this);
        Bukkit.getPluginManager().registerEvents(new ItemProtectionListener(), this);
        Bukkit.getPluginManager().registerEvents(this, this);
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (shouldReceiveItems(player)) {
                giveVisibilityItems(player);
            }
        }
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            visibilityManager.showAllPlayers(player);
        }
    }

    public VisibilityManager getVisibilityManager() {
        return visibilityManager;
    }

    @EventHandler
    public void onPlayerJoinForItems(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        if (shouldReceiveItems(player)) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline() && shouldReceiveItems(player)) {
                    giveVisibilityItems(player);
                }
            }, 5L);
        }
    }

    private void createVisibilityItems() {
        this.redDyeItem = new ItemStack(Material.RED_DYE);
        ItemMeta redMeta = redDyeItem.getItemMeta();
        redMeta.setDisplayName(RED_DYE_NAME);
        redDyeItem.setItemMeta(redMeta);

        this.greenDyeItem = new ItemStack(Material.GREEN_DYE);
        ItemMeta greenMeta = greenDyeItem.getItemMeta();
        greenMeta.setDisplayName(GREEN_DYE_NAME);
        greenDyeItem.setItemMeta(greenMeta);
    }

    private boolean shouldReceiveItems(Player player) {
        GameMode mode = player.getGameMode();
        return mode == GameMode.SURVIVAL || mode == GameMode.ADVENTURE;
    }

    private void giveVisibilityItems(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() == Material.AIR) {
                continue;
            }

            if (item.getType() != Material.RED_DYE && item.getType() != Material.GREEN_DYE) {
                continue;
            }

            if (!item.hasItemMeta()) {
                continue;
            }

            ItemMeta meta = item.getItemMeta();
            if (!meta.hasDisplayName()) {
                continue;
            }

            String displayName = meta.getDisplayName();
            if (displayName.equals(RED_DYE_NAME) || displayName.equals(GREEN_DYE_NAME)) {
                player.getInventory().setItem(i, null);
            }
        }

        player.getInventory().setItem(7, redDyeItem.clone());
        player.getInventory().setItem(8, greenDyeItem.clone());
    }
}
