package de.sweatervibes.lobby;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class VisibilityManager {

    private final LobbyPlugin plugin;
    private final Map<UUID, Set<UUID>> hiddenPlayers = new HashMap<>();

    public VisibilityManager(LobbyPlugin plugin) {
        this.plugin = plugin;
    }

    public void hideAllPlayers(Player viewer) {
        UUID viewerId = viewer.getUniqueId();
        Set<UUID> hidden = hiddenPlayers.computeIfAbsent(viewerId, k -> new HashSet<>());

        if (!hidden.isEmpty()) {
            viewer.sendMessage("§cAlle Spieler sind bereits versteckt!");
            return;
        }

        for (Player target : Bukkit.getOnlinePlayers()) {
            if (!target.equals(viewer)) {
                viewer.hidePlayer(plugin, target);
                hidden.add(target.getUniqueId());
            }
        }

        viewer.sendMessage("§cAlle Spieler sind jetzt versteckt!");
    }

    public void showAllPlayers(Player viewer) {
        UUID viewerId = viewer.getUniqueId();
        Set<UUID> hidden = hiddenPlayers.get(viewerId);

        if (hidden == null || hidden.isEmpty()) {
            viewer.sendMessage("§aAlle Spieler sind bereits sichtbar!");
            return;
        }

        for (Player target : Bukkit.getOnlinePlayers()) {
            if (!target.equals(viewer)) {
                viewer.showPlayer(plugin, target);
            }
        }

        hidden.clear();
        viewer.sendMessage("§aAlle Spieler sind jetzt sichtbar!");
    }

    public boolean isHiding(Player viewer) {
        Set<UUID> hidden = hiddenPlayers.get(viewer.getUniqueId());
        return hidden != null && !hidden.isEmpty();
    }

    public void cleanup(Player player) {
        hiddenPlayers.remove(player.getUniqueId());
    }
}
