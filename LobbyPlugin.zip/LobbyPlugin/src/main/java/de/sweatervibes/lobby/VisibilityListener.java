package de.sweatervibes.lobby;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class VisibilityListener implements Listener {

    private static final String RED_DYE_NAME = "§cSpieler verstecken";
    private static final String GREEN_DYE_NAME = "§aSpieler anzeigen";

    private final LobbyPlugin plugin;
    private final VisibilityManager visibilityManager;

    public VisibilityListener(LobbyPlugin plugin, VisibilityManager visibilityManager) {
        this.plugin = plugin;
        this.visibilityManager = visibilityManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (!isVisibilityItem(item)) {
            return;
        }

        event.setCancelled(true);
        
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        String displayName = item.getItemMeta().getDisplayName();

        if (displayName.equals(RED_DYE_NAME)) {
            visibilityManager.hideAllPlayers(player);
        } else if (displayName.equals(GREEN_DYE_NAME)) {
            visibilityManager.showAllPlayers(player);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player joiner = event.getPlayer();
        
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (visibilityManager.isHiding(online) && !online.equals(joiner)) {
                online.hidePlayer(plugin, joiner);
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        visibilityManager.cleanup(event.getPlayer());
    }

    private boolean isVisibilityItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return false;
        }

        Material type = item.getType();
        if (type != Material.RED_DYE && type != Material.GREEN_DYE) {
            return false;
        }

        if (!item.hasItemMeta()) {
            return false;
        }

        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) {
            return false;
        }

        String displayName = meta.getDisplayName();
        return displayName.equals(RED_DYE_NAME) || displayName.equals(GREEN_DYE_NAME);
    }
}
